## 0.0.1.1
### No issue

**Added Jenkinsfile.**


[66fe4aad02406c3](https://github.com/jcustenborder/kafka-connect-snmp/commit/66fe4aad02406c3) Jeremy Custenborder *2017-02-15 05:58:08*

**Corrected class.**


[8760ef8af030cfb](https://github.com/jcustenborder/kafka-connect-snmp/commit/8760ef8af030cfb) Jeremy Custenborder *2017-02-15 05:54:04*


