## 1.0.9
### No issue

**Schema refactor (#17)**

* Refactored to add support for json. Added experimental support for tracking offsets. Moved to require schemas to be supplied.
* Modified scope to ensure that jackson is in target directory.
* Updated the docker compose to the latest version
* Updated data files with changes from offsets.
* Added documentation test.
* Bumped version to 0.10.2.0-cp1.
* Added support to throw a contextual exception when a record cannot be parsed. This will throw the record and field.
* Added support to write records with a timestamp.
* Added description to connectors.
* Added generators to aid in building schemas for the input files. Added a command line utility as well.
* Added validation of character sets.
* Added support to dynamically generate schemas if `schema.generation.enabled` is set to true.
* Pulled out jfairy because it&#39;s no longer used.
* Updated the documentation.
* Modified so SimpleDateFormat is being set with the correct timezone. This was causing tests to fail in other timezones like UTC.

[f14906f3fd81a79](https://github.com/jcustenborder/kafka-connect-spooldir/commit/f14906f3fd81a79) Jeremy Custenborder *2017-05-29 02:56:36*


## 0.1.7
### No issue

**Corrected schema registry image.**


[464603a3ea40a4b](https://github.com/jcustenborder/kafka-connect-spooldir/commit/464603a3ea40a4b) Jeremy Custenborder *2016-11-04 20:04:03*

**Moved all of the documentation back to markdown.**


[45a3eacf9c01464](https://github.com/jcustenborder/kafka-connect-spooldir/commit/45a3eacf9c01464) Jeremy Custenborder *2016-09-07 05:38:53*

**Changed assembly to ouput a tar.gz**


[7b2dce5e2c593b6](https://github.com/jcustenborder/kafka-connect-spooldir/commit/7b2dce5e2c593b6) Jeremy Custenborder *2016-09-07 05:33:11*


## 0.1.6
### No issue

**Changed the displayname parameter for a few fields in the CSVRecordProcessorConfig**


[6e8954d925d9971](https://github.com/jcustenborder/kafka-connect-spooldir/commit/6e8954d925d9971) Chris Matta *2016-09-15 18:02:51*


## 0.1.5
### No issue

**Changed to include developer SCM data so the releases plugin will upload properly.**


[cb7abea45b497d6](https://github.com/jcustenborder/kafka-connect-spooldir/commit/cb7abea45b497d6) Jeremy Custenborder *2016-09-07 05:26:38*

**Updated license header.**


[243fbb8f6108bcc](https://github.com/jcustenborder/kafka-connect-spooldir/commit/243fbb8f6108bcc) Jeremy Custenborder *2016-09-07 05:20:13*

**Deploy to github releases.**


[f12eba253a6f4b6](https://github.com/jcustenborder/kafka-connect-spooldir/commit/f12eba253a6f4b6) Jeremy Custenborder *2016-09-07 05:16:08*

**Added logging for testing.**


[3748e346703a5a1](https://github.com/jcustenborder/kafka-connect-spooldir/commit/3748e346703a5a1) Jeremy Custenborder *2016-08-23 03:35:59*

**Added confluent repository.**


[c8610c37fb26fba](https://github.com/jcustenborder/kafka-connect-spooldir/commit/c8610c37fb26fba) Jeremy Custenborder *2016-08-23 03:30:09*

**Initial commit for Jenkinsfile.**


[139ed2da2514c70](https://github.com/jcustenborder/kafka-connect-spooldir/commit/139ed2da2514c70) Jeremy Custenborder *2016-08-23 03:26:10*

**Changes to pull connect-utils from maven central.**


[a98dc0b7aa32fff](https://github.com/jcustenborder/kafka-connect-spooldir/commit/a98dc0b7aa32fff) Jeremy Custenborder *2016-08-23 03:21:57*

**Added settings to control the output schema name for a generated schema.**


[02a0071767974d3](https://github.com/jcustenborder/kafka-connect-spooldir/commit/02a0071767974d3) Jeremy Custenborder *2016-07-19 18:22:43*

**Corrected test cases for maven. Added metadata to the record if configured.**


[c606245639e26bb](https://github.com/jcustenborder/kafka-connect-spooldir/commit/c606245639e26bb) Jeremy Custenborder *2016-07-12 13:22:43*

**Cleanup of refactor in strings.**


[d61d1d8b5af3ee9](https://github.com/jcustenborder/kafka-connect-spooldir/commit/d61d1d8b5af3ee9) Jeremy Custenborder *2016-07-11 21:56:28*

**Rename the file once before it has started processing.**


[a060f567ad6eb10](https://github.com/jcustenborder/kafka-connect-spooldir/commit/a060f567ad6eb10) Jeremy Custenborder *2016-07-11 17:57:17*

**Added more testing around not having keys defined. This should result in a null schema and a null object ending up in the connect record.**


[7c49df8804a986f](https://github.com/jcustenborder/kafka-connect-spooldir/commit/7c49df8804a986f) Jeremy Custenborder *2016-07-10 02:28:24*

**Added more test cases around non defined schemas. Extend SchemaConfig tests to validate the key schema. Refactored CSVRecordProcessor to use data package. Added more documentation to RST.**


[e2361cc656c32df](https://github.com/jcustenborder/kafka-connect-spooldir/commit/e2361cc656c32df) Jeremy Custenborder *2016-07-10 02:16:31*

**Hopefully corrected RST.**


[1851a2b7b12de45](https://github.com/jcustenborder/kafka-connect-spooldir/commit/1851a2b7b12de45) Jeremy Custenborder *2016-07-10 01:15:01*

**Added more documentation and moved some common functionality out to connect-utils.**


[00ceb01d64764a2](https://github.com/jcustenborder/kafka-connect-spooldir/commit/00ceb01d64764a2) Jeremy Custenborder *2016-07-10 01:13:51*

**Cleanup schema generation code. Clarified support for generating a schema based on the the header row. Indexes for specified schemas are indexed based on the header row if it is used. Added checkstyle.**


[28c0590ebe8f62b](https://github.com/jcustenborder/kafka-connect-spooldir/commit/28c0590ebe8f62b) Jeremy Custenborder *2016-07-09 17:05:05*

**Moved schema generation over to SchemaConfig class. Added tests for this. Added license headers to all classes.**


[afae51b55c605dd](https://github.com/jcustenborder/kafka-connect-spooldir/commit/afae51b55c605dd) Jeremy Custenborder *2016-07-08 15:30:00*

**Added scripts to run with debugging or suspend with debugging.**


[bbeca70262f7db1](https://github.com/jcustenborder/kafka-connect-spooldir/commit/bbeca70262f7db1) Jeremy Custenborder *2016-07-08 07:48:35*

**Corrected formatting.**


[41d0c16a077f3e0](https://github.com/jcustenborder/kafka-connect-spooldir/commit/41d0c16a077f3e0) Jeremy Custenborder *2016-07-08 07:46:18*

**Corrected formatting.**


[f8982d33f93582c](https://github.com/jcustenborder/kafka-connect-spooldir/commit/f8982d33f93582c) Jeremy Custenborder *2016-07-08 07:44:39*

**Added documentation on how to build.**


[04186b322fd4934](https://github.com/jcustenborder/kafka-connect-spooldir/commit/04186b322fd4934) Jeremy Custenborder *2016-07-08 07:43:54*

**Major refactor to combine all of the configs and go to a json based configuration for the connect schema. Cleanup work is still needed in the case you are not specifying fields.**


[01ae8d6d6ed34b2](https://github.com/jcustenborder/kafka-connect-spooldir/commit/01ae8d6d6ed34b2) Jeremy Custenborder *2016-07-08 07:35:56*

**Moved charset setting to file.charset for consistency.**


[c1a35c307eba3dd](https://github.com/jcustenborder/kafka-connect-spooldir/commit/c1a35c307eba3dd) Jeremy Custenborder *2016-07-07 15:25:11*

**Added setting to allow a minimum file age.**


[50aeca0258424cd](https://github.com/jcustenborder/kafka-connect-spooldir/commit/50aeca0258424cd) Jeremy Custenborder *2016-07-07 15:24:38*

**Added some logging defaulting to 20x the batch size.**


[1cf63344ba37147](https://github.com/jcustenborder/kafka-connect-spooldir/commit/1cf63344ba37147) Jeremy Custenborder *2016-07-07 06:58:46*

**Cleanup the documentation for null fields in a CSV.**


[120ea0e56f98392](https://github.com/jcustenborder/kafka-connect-spooldir/commit/120ea0e56f98392) Jeremy Custenborder *2016-07-07 06:47:58*

**Remove the markdown for the rst.**


[ce0e1a248555346](https://github.com/jcustenborder/kafka-connect-spooldir/commit/ce0e1a248555346) Jeremy Custenborder *2016-07-07 06:43:11*

**Added more documentation.**


[f69780dd8ca458b](https://github.com/jcustenborder/kafka-connect-spooldir/commit/f69780dd8ca458b) Jeremy Custenborder *2016-07-07 06:42:17*

**First working pass supporting both a text only mode directly from the header of a CSV and specific configuration through the config file. Decent parsing speed.**


[bdbe92a2fa4e4ff](https://github.com/jcustenborder/kafka-connect-spooldir/commit/bdbe92a2fa4e4ff) Jeremy Custenborder *2016-07-07 05:44:24*

**Added more documentation.**


[0535f425d798085](https://github.com/jcustenborder/kafka-connect-spooldir/commit/0535f425d798085) Jeremy Custenborder *2016-07-06 22:01:41*

**Added indexes to field config. Added more type testing.**


[abce419831b517a](https://github.com/jcustenborder/kafka-connect-spooldir/commit/abce419831b517a) Jeremy Custenborder *2016-07-06 21:48:17*

**Cleanup from code analysis.**


[e9b3d567924f5b6](https://github.com/jcustenborder/kafka-connect-spooldir/commit/e9b3d567924f5b6) Jeremy Custenborder *2016-07-05 05:51:05*

**Corrected file formatting.**


[79b79bbfcceac7b](https://github.com/jcustenborder/kafka-connect-spooldir/commit/79b79bbfcceac7b) Jeremy Custenborder *2016-07-05 05:12:00*

**Changed to support changing the file encoding from the default.**


[992f5bb7b4b09ba](https://github.com/jcustenborder/kafka-connect-spooldir/commit/992f5bb7b4b09ba) Jeremy Custenborder *2016-07-05 05:11:02*

**Cleanup of some errors from FindBugs.**


[2b442f83d65b084](https://github.com/jcustenborder/kafka-connect-spooldir/commit/2b442f83d65b084) Jeremy Custenborder *2016-07-05 02:18:27*

**Cleanup of some errors from FindBugs.**


[448e6bcee2819ee](https://github.com/jcustenborder/kafka-connect-spooldir/commit/448e6bcee2819ee) Jeremy Custenborder *2016-07-05 02:11:43*

**Cleanup formatting.**


[e08209932d6d144](https://github.com/jcustenborder/kafka-connect-spooldir/commit/e08209932d6d144) Jeremy Custenborder *2016-07-05 02:03:18*

**CSV Support is working. Directory polling as well.**


[e58fe84c800daad](https://github.com/jcustenborder/kafka-connect-spooldir/commit/e58fe84c800daad) Jeremy Custenborder *2016-07-05 02:02:08*


